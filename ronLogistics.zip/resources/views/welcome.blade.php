<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @livewireStyles
</head>
<body>
    <h1 center>Hello There!
    <i class="fas fa-home mr-2"></i>Home<br>
    <i class="fab fa-laravel mr-2"></i>Lara
    </h1>
</body>
</html>