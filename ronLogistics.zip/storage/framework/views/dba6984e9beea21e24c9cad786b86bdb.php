<tr <?php echo e($attributes->merge(['class' => 'hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors'])); ?>>
    <?php echo e($slot); ?>

</tr><?php /**PATH C:\Development\ronLogistics\resources\views/components/table/row.blade.php ENDPATH**/ ?>