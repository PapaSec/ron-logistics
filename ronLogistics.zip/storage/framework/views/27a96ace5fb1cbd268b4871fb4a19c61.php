<div <?php echo e($attributes->merge(['class' => 'bg-[#E4EBE7] dark:bg-[#1f2431] rounded-lg p-6'])); ?>>
    <div class="flex items-center justify-between">
        <div>
            <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($value); ?></p>
            <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($title); ?></p>
            
            <!--[if BLOCK]><![endif]--><?php if($showTrend): ?>
                <div class="flex items-center mt-2">
                    <span class="text-xs <?php echo e(str_starts_with($trend, '+') ? 'text-green-500' : 'text-red-500'); ?> font-medium">
                        <i class="fas <?php echo e(str_starts_with($trend, '+') ? 'fa-arrow-up' : 'fa-arrow-down'); ?> mr-1"></i>
                        <?php echo e($trend); ?>

                    </span>
                    <span class="text-xs text-gray-500 dark:text-gray-400 ml-2"><?php echo e($trendText); ?></span>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        
        <div class="w-12 h-12 rounded-lg flex items-center justify-center <?php echo e($iconBg); ?>">
            <i class="<?php echo e($icon); ?> text-xl <?php echo e($iconColor); ?>"></i>
        </div>
    </div>
</div><?php /**PATH C:\Development\ronLogistics\resources\views/components/stats-card.blade.php ENDPATH**/ ?>