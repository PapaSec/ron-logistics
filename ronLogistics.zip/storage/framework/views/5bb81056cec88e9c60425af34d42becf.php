<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'name',
    'required' => false,
    'icon' => 'fas fa-chevron-down',
    'model' => null,
    'options' => [],
    'selected' => null,
    'placeholder' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'name',
    'required' => false,
    'icon' => 'fas fa-chevron-down',
    'model' => null,
    'options' => [],
    'selected' => null,
    'placeholder' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="group" wire:key="<?php echo e($name); ?>">
    <!--[if BLOCK]><![endif]--><?php if($label): ?>
        <label for="<?php echo e($name); ?>" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            <?php echo e($label); ?> <!--[if BLOCK]><![endif]--><?php if($required): ?><span class="text-red-500">*</span><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </label>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
    <div class="relative">
        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <i class="<?php echo e($icon); ?> text-gray-400 transition-colors duration-200 group-focus-within:text-blue-400"></i>
        </div>
        <select 
            id="<?php echo e($name); ?>" 
            name="<?php echo e($name); ?>"
            <?php if($model): ?> wire:model="<?php echo e($model); ?>" <?php endif; ?>
            <?php echo e($attributes->merge([
                'class' => 'w-full pl-11 pr-10 py-2.5 bg-white dark:bg-white/5 text-gray-900 dark:text-gray-500 rounded-xl border border-gray-300 dark:border-white/10 focus:border-blue-500/50 focus:bg-white dark:focus:bg-white/10 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 appearance-none',
                'required' => $required
            ])); ?>

        >
            <option value=""><?php echo e($placeholder ?? ($label ? 'Select ' . strtolower($label) : 'Choose an option')); ?></option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>" <?php echo e(($selected ?? old($name)) == $value ? 'selected' : ''); ?>>
                    <?php echo e($text); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>
        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <i class="fas fa-chevron-down text-gray-400"></i>
        </div>
    </div>
    
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$model ?? $name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\Development\ronLogistics\resources\views/components/inputs/select.blade.php ENDPATH**/ ?>