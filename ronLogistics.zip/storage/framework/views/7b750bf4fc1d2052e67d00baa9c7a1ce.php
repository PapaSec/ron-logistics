<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'button', // Add type prop
    'href' => null,
    'icon' => null,
    'style' => 'primary',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'button', // Add type prop
    'href' => null,
    'icon' => null,
    'style' => 'primary',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $baseClasses = 'rounded-lg px-4 py-2 flex items-center transition-colors duration-150 font-medium';
    
    $styleClasses = match ($style) {
        'secondary' => 'bg-gray-200 hover:bg-gray-300 text-gray-800 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-200',
        'back' => 'bg-black hover:bg-gray-900 text-white',
        'cancel' => 'bg-red-500 hover:bg-red-600 text-white',
        'submit' => 'bg-green-600 hover:bg-green-700 text-white',
        'reset' => 'bg-yellow-700 hover:bg-yellow-600 text-white',
        'clear' => 'px-4 py-2.5 bg-red-500 hover:bg-red-600 text-white transition-all duration-200 flex items-center justify-center',
        'edit' => 'bg-blue-500 hover:bg-blue-600',
        'delete' => 'bg-red-500 hover:bg-red-600',
        'print' => 'bg-gray-900 hover:bg-gray-800 text-white',
        default => 'bg-[#138898] hover:bg-[#1388980] text-white',
    };
?>

<!--[if BLOCK]><![endif]--><?php if($href): ?>
    <a href="<?php echo e($href); ?>" 
        <?php echo e($attributes->merge(['class' => $baseClasses . ' ' . $styleClasses])); ?>>
        <!--[if BLOCK]><![endif]--><?php if($icon): ?><i class="<?php echo e($icon); ?> mr-2"></i><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php echo e($slot); ?>

    </a>
<?php else: ?>
    <button type="<?php echo e($type); ?>" 
        <?php echo e($attributes->merge(['class' => $baseClasses . ' ' . $styleClasses])); ?>>
        <!--[if BLOCK]><![endif]--><?php if($icon): ?><i class="<?php echo e($icon); ?> mr-2"></i><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php echo e($slot); ?>

    </button>
<?php endif; ?><!--[if ENDBLOCK]><![endif]--><?php /**PATH C:\Development\ronLogistics\resources\views/components/button.blade.php ENDPATH**/ ?>