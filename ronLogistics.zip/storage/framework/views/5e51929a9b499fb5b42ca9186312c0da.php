<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['scrollable' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['scrollable' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'bg-white dark:bg-gray-900 rounded-lg shadow'])); ?>>
    <div class="<?php echo e($scrollable ? 'overflow-x-auto table-scrollbar' : ''); ?>">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <?php echo e($slot); ?>

        </table>
    </div>
</div><?php /**PATH C:\Development\ronLogistics\resources\views/components/table/wrapper.blade.php ENDPATH**/ ?>