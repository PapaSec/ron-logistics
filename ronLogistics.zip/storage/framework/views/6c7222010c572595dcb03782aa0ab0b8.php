<tbody <?php echo e($attributes->merge(['class' => 'bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700'])); ?>>
    <?php echo e($slot); ?>

</tbody><?php /**PATH C:\Development\ronLogistics\resources\views/components/table/body.blade.php ENDPATH**/ ?>